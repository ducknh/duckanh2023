
public class Car implements EngineCar {
    // Các phương thức của EngineCar và Transmission được cài đặt ở đây
	//Có thể thực hiện nhiều interface
	
	@Override
	public void Start() {
		// TODO Auto-generated method stub
		System.out.println("Khởi động xe!");
	}

	@Override
	public void Stop() {
		// TODO Auto-generated method stub
		System.out.println("Dừng xe!");
	}

	@Override
	public void Brake() {
		// TODO Auto-generated method stub
		System.out.println("Phanh xe lại!");
	}
}
