
public class myprogram {

	public myprogram() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Car a = new Car();
		
		a.Start();
		a.Stop();
		a.Brake();
	}

}
