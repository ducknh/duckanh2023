// Khởi tạo phương thức
interface EngineCar {
	void Start();
	void Stop();
	void Brake();
}
