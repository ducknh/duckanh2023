package Students;

import model.Student;

import java.util.ArrayList;
import java.util.Scanner;

import static model.Student.studentId;

public class StudentInput{
	Input input = new Input();
	
	ArrayList<Student> list = new ArrayList<>();
	
	Scanner sc = new Scanner(System.in);
	Student s = new Student();
	
	public void addStudent() {
		String studentName = getStudentName();
		int studentAge = getStudentAge();
		boolean studentIsMale = getStudentGender();
		int studentClassId = getStudentClassId();
		Student s = new Student(studentName, studentAge, studentIsMale, studentClassId);
		list.add(s);
		showStudent();
	}
	
	public void updateStudent() {
		System.out.println("Enter id");
		int id = input.chooseOptionFromRange(1, studentId);
		if(findStudentById(id) == null) {
			System.out.println("This Id does not exist");
		}
		else {
			for(int i = 0; i < list.size(); i++) {
				if(id == list.get(i).getId()) {
					String studentName = getStudentName();
					int studentAge = getStudentAge();
					boolean studentIsMale = getStudentGender();
					int studentClassId = getStudentClassId();
					list.get(i).setName(studentName);
					list.get(i).setAge(studentAge);
					list.get(i).setMale(studentIsMale);
					list.get(i).setClassId(studentClassId);
				}
			}
		}
		showStudent();
	}
	
	public void deleteStudent() {
		System.out.println("Enter Id");
		int id = input.chooseOptionFromRange(1, studentId);
		if(findStudentById(id) == null) {
			System.out.println("This Id does not exist");
		}else {
			for(int i = 0; i < list.size(); i++) {
				if(id == list.get(i).getId()) {
					list.remove(i);
				}
			}
		}
		showStudent();
	}
	
	public Student findStudentById(int id) {
		for(int i = 0; i < list.size(); i++) {
			if(id == list.get(i).getId()) {
				return list.get(i);
			}
		}
		return null;
	}
	
	public String getStudentName() {
		System.out.println("Enter Student Name: ");
		String name = sc.nextLine();
		return name;
	}
	
	public int getStudentAge() {
		System.out.println("Enter Student Age: ");
		int age = input.chooseOptionFromRange(18, 100);
		return age;
	}
	
	public boolean getStudentGender() {
		System.out.println("Is Student Male ?");
		boolean gender = input.chooseFromBoolean();
		return gender;
	}
	
	public int getStudentClassId() {
		System.out.println("Enter Student Class ID: ");
		int classid = input.chooseOptionFromRange(1, 10);
		return classid;
	}
	
	public void showStudent() {
		for(int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i));
		}
	}
}