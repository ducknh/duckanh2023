package Students;

import java.util.Scanner;

public class Input{
	Scanner sc = new Scanner(System.in);
	
	public int chooseOptionFromRange(int low, int high){
		while(true) {
			try {
				System.out.println("Enter your option: ");
				String option = sc.next();
				int validOption = Integer.parseInt(option);
				if(validOption >= low && validOption <= high) {
					return validOption;
				}else {
					invalidChooseFromRange(low, high);
				}
			} catch (Exception e){
				invalidChooseFromRange(low, high);
			}
		}
	}
	
	public boolean chooseFromBoolean(){
		while(true) {
			System.out.println("Enter your answer");
			String option = sc.next();
			if(option.equalsIgnoreCase("TRUE")) {
				return true;
			}
			else if(option.equalsIgnoreCase("FALSE")){
				return false;
			}
			else {
				invalidChooseFromBoolean();
			}
		}
	}
	private void invalidChooseFromBoolean() {
		// TODO Auto-generated method stub
		System.out.println("Invalid Input! Please enter True or False");
	}

	private void invalidChooseFromRange(int low, int high) {
		// TODO Auto-generated method stub
		System.out.println("Invalid Input! Please enter from " + low + " to " + high);
	}
}