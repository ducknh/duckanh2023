package Students;

public class Display{
	Input input = new Input();
	
	StudentInput studentinput = new StudentInput();
	
	public void DisplayApplication() {
		while (true) {
			System.out.println("Choose your option");
			System.out.println("1/ Add a Student");
			System.out.println("2/ Update a Student");
			System.out.println("3/ Delete a Student");
			System.out.println("4/ Show Students");
			System.out.println("5/ Quit");
			
			int option = input.chooseOptionFromRange(1,5);
			switch(option) {
				case 1:
					studentinput.addStudent();
					break;
				case 2:
					studentinput.updateStudent();
					break;
				case 3:
					studentinput.deleteStudent();
					break;
				case 4:
					studentinput.showStudent();
					break;
				case 5:
					return;
			}
		}
	}
}