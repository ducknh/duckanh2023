package Student;

public interface INoiQuy {
	void Rulesfollow();
}
