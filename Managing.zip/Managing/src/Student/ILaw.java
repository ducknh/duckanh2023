package Student;

public interface ILaw {
	void followLaw();
}
