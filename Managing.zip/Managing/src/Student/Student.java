package Student;

import Person.Person;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Student extends Person implements INoiQuy, ILaw {
	private int studentId;
	private String studentRegno;
	private String studentClass; 
	private List<Student> list;
	private Scanner s;
	
	public Student() {
		// TODO Auto-generated constructor stub
		list = new ArrayList<>();
		s = new Scanner(System.in);
	}
	
	public Student(String name, String dateOfBirth, int studentId, String studentRegno, String studentClass) {
		super(name, dateOfBirth);
		this.studentId = studentId;
		this.studentRegno = studentRegno;
		this.studentClass = studentClass;
	}
	

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	
	public String getStudentRegno() {
		return studentRegno;
	}

	public void setStudentRegno(String studentRegno) {
		this.studentRegno = studentRegno;
	}

	public String getStudentClass() {
		return studentClass;
	}

	public void setStudentClass(String studentClass) {
		this.studentClass = studentClass;
	}
	
	public void AddStudent() {
		System.out.println("Enter the number of Student you wanna input: ");
		int n = validation(0);
		for(int i = 0; i < n; i++) {
			System.out.println("Student number " + (i + 1) + ":");
			System.out.println("Enter Student ID: ");
			this.studentId = validation(studentId);
			System.out.println("Enter Student Name: ");
			this.name = s.nextLine();
			System.out.println("Enter Student Registration Number: ");
			this.studentRegno = s.nextLine();
			System.out.println("Enter Student Date Of Birth: ");
			this.dateOfBirth = s.nextLine();
			System.out.println("Enter Student Class: ");
			this.studentClass = s.nextLine();
			
			Student student = new Student();
			list.add(student);
			System.out.println("Input Student Successfully!");
		}
	}
	
	public void ShowStudent() {
		if(list.isEmpty()) {
			System.out.println("No Student Found!");
		}else {
			for(Student student : list) {
				System.out.println(student.toString());
			}
		}
	}
	
	public void UpdateStudent() {
		System.out.println("Enter Student ID for updating: ");
		int FindStudentId = validation(0);
		for(Student student : list) {
			if(FindStudentId == student.getStudentId()) {
				System.out.println("Enter New Name: ");
				String name = s.nextLine();
				System.out.println("Enter New Registration Number: ");
				String regno = s.nextLine();
				System.out.println("Enter New Date of Birth: ");
				String dateOfBirth = s.nextLine();
				System.out.println("Enter New Class: ");
				String stuClass = s.nextLine();
				student.setName(name);
				student.setStudentRegno(regno);
				student.setDateOfBirth(dateOfBirth);
				student.setStudentClass(stuClass);
			}else {
				System.out.println("No Student Found");
			}
		}
	}
	
	public void DeleteStudent() {
		System.out.println("Enter Student ID for updating: ");
		int FindStudentId = validation(0);
		for(Student student : list) {
			if(FindStudentId == student.getStudentId()) {
				list.remove(student);
				System.out.println("Student has been deleted successfully!");
			}else {
				System.out.println("No Student Found");
			}
		}
	}
	
	public void Search() {
		System.out.println("Enter Name or Registration Number for Searching Student: ");
		String FindStudent = s.nextLine();
		for(Student student : list) {
			if(student.getName().equalsIgnoreCase(FindStudent) ||
			   student.getStudentRegno().equalsIgnoreCase(FindStudent)) {
			   System.out.println("Student's info found, here is information: ");
			   System.out.println(student.toString());
			}
		}
	}
	
	@Override
	public void followLaw() {
		// TODO Auto-generated method stub
		System.out.println("Học sinh không phạm lỗi!");	
	}

	@Override
	public void Rulesfollow() {
		// TODO Auto-generated method stub
		System.out.println("Học sinh tuân thủ nội quy");	
	}

	@Override
	public int validation(int validate) {
		// TODO Auto-generated method stub
		while(true) {
			try {
				validate = Integer.parseInt(s.nextLine());
				return validate;
			} catch(NumberFormatException e) {
				System.out.println("Invalid input! You must input numbers only: ");
			}
		}
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return  "Student ID: " + studentId +
				"Student Name: " + name +
				"Student Registration Number: " + studentRegno +
				"Student Date Of Birth: " + dateOfBirth +
				"Student Class: " + studentClass;
	}
}
