package Person;

public abstract class Person {
	protected String name;
	protected String dateOfBirth;
	
	public Person() {
		// TODO Auto-generated constructor stub
	}
	
	public Person(String name, String dateOfBirth) {
		this.name = name;
		this.dateOfBirth = dateOfBirth;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	
	public abstract String toString();
	
	public abstract int validation(int validate);
}
