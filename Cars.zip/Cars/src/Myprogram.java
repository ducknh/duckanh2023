import java.util.Scanner;

public class Myprogram {

	public Myprogram() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {

		// TODO Auto-generated method stub
//		Car a = new Car("Audi", "Luxury", "05C28", "02FLC", "145");
//		Car b = new Car("BMV", "Busted", "06F89", "27FC", "2099");
//		Car c = new Car("IIX", "Merc", "46AC", "57FC", "2199");
//		
//		a.displayInfo();
//		b.displayInfo();
//		c.displayInfo();
//		
//		Car d = new Car();
//		d.setBrand("I Kyamorning");
//		d.setType("Elegant");
//		d.setLicensePlate("08FV");
//		d.setChassisNumber("89CKL");
//		d.setEngineNumber("09R4");
//		d.displayInfo();
		
//		MyCar e = new MyCar("Mercesdes", "Alan", "04C28", "069F", "24", "Merc");
//		e.displayMyCarInfo();
//		e.setLogo("Vinfast");
//		e.displayMyCarInfo();
		
//		Scanner scanner = new Scanner(System.in);
//
//        System.out.println("Enter brand:");
//        String brand = scanner.nextLine();
//
//        System.out.println("Enter type:");
//        String type = scanner.nextLine();
//
//        System.out.println("Enter license plate:");
//        String licensePlate = scanner.nextLine();
//
//        System.out.println("Enter chassis number:");
//        String chassisNumber = scanner.nextLine();
//
//        System.out.println("Enter engine number:");
//        String engineNumber = scanner.nextLine();
//
//        // Tạo một đối tượng Car với thông tin đã nhập từ bàn phím
//        Car myCar = new Car(brand, type, licensePlate, chassisNumber, engineNumber);
//        myCar.displayInfo();
//
//        // Đóng Scanner
//        scanner.close();
//		
//		MyCar.getOwner();
		
		Scanner s = new Scanner(System.in);
		
		boolean i = true;
		while(i) {
			System.out.println("Menu");
			System.out.println("1/ Them xe");
			System.out.println("2/ Danh sach xe");
			System.out.println("3/ Tim kiem xe");
			System.out.println("4/ Xoa xe");
			System.out.println("5/ Thoat");
			System.out.println("Lua chon cua ban: [Từ 1 đến 5]");
			
			String option = s.nextLine();
			
			switch (option) {
		    case "1":
		        ThemXe();
		        break;
		    case "2":
		        DanhSachXe();
		        break;
		    case "3":
		        TimKiemXe();
		        break;
		    case "4":
		        XoaXe();
		        break;
		    case "5":
		        i = false;
		        break;
		    default:
		        System.out.println("Lua chon khong hop le");
		        break;
			}
		}
		s.close();
	}
	
		public static void ThemXe() {
			Scanner s = new Scanner(System.in);
			
			System.out.println("Hệ thống đã thêm xe");
			System.out.println("Enter brand:");
	        String brand = s.nextLine();
	
	        System.out.println("Enter type:");
	        String type = s.nextLine();
	
	        System.out.println("Enter license plate:");
	        String licensePlate = s.nextLine();
	
	        System.out.println("Enter chassis number:");
	        String chassisNumber = s.nextLine();
	
	        System.out.println("Enter engine number:");
	        String engineNumber = s.nextLine();
	        
//	        int soDongCo = 0;
//	        boolean nhapDung = false;

//	        while (!nhapDung) {
//	            System.out.println("Enter so Dong Co:");
//	            try {
//	                soDongCo = Integer.parseInt(s.nextLine());
//	                nhapDung = true;
//	            } catch (NumberFormatException e) {
//	                System.out.println("Bạn phải nhập số nguyên. Vui lòng thử lại.");
//	            }
//	        }
	        System.out.println("Nhập số động cơ: ");
	        int soDongCo = Validate.nhapSoNguyen();
	        System.out.println(soDongCo);
	        
		}
		
		public static void DanhSachXe() {
			System.out.println("Danh sách xe: ");
		}
		
		public static void TimKiemXe() {
			System.out.println("Nhap xe ban muôn tìm: ");
		}
		
		public static void XoaXe() {
			System.out.println("Nhap xe ban muôn xóa: ");
		}
}

