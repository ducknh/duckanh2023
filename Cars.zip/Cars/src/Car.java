
public class Car implements IEngine {
	
	private String brand;   // Hãng xe
    private String type;    // Loại xe
    private String licensePlate; // Biển số
    private String chassisNumber; // Số khung
    private String engineNumber; // Số máy
    private String logo;
    private int soDongCo;
    
	public Car() {
		// TODO Auto-generated constructor stub
		
	}
	
	public Car(String brand, String type, String licensePlate, String chassisNumber, String engineNumber) {
        this.brand = brand;
        this.type = type;
        this.licensePlate = licensePlate;
        this.chassisNumber = chassisNumber;
        this.engineNumber = engineNumber;
    }
	
	public Car(String brand, String type, String licensePlate, String chassisNumber, String engineNumber, String logo, int soDongCo) {
        this.brand = brand;
        this.type = type;
        this.licensePlate = licensePlate;
        this.chassisNumber = chassisNumber;
        this.engineNumber = engineNumber;
        this.logo = logo;
        this.soDongCo = soDongCo;
    }
	
	protected String getBrand() {
		return brand;
	}

	protected void setBrand(String brand) {
		this.brand = brand;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getLicensePlate() {
		return licensePlate;
	}

	public void setLicensePlate(String licensePlate) {
		this.licensePlate = licensePlate;
	}

	public String getChassisNumber() {
		return chassisNumber;
	}

	public void setChassisNumber(String chassisNumber) {
		this.chassisNumber = chassisNumber;
	}

	public String getEngineNumber() {
		return engineNumber;
	}

	public void setEngineNumber(String engineNumber) {
		this.engineNumber = engineNumber;
	}

	
	
	public void displayInfo() {
	    System.out.println("Car Information:");
	    System.out.println("Brand: " + brand);
	    System.out.println("Type: " + type);
	    System.out.println("License Plate: " + licensePlate);
	    System.out.println("Chassis Number: " + chassisNumber);
	    System.out.println("Engine Number: " + engineNumber);
	}

	@Override
	public void Start() {
		// TODO Auto-generated method stub
		System.out.println("Xe bat dau chuyen dong!");
	}

	@Override
	public void Stop() {
		// TODO Auto-generated method stub
		System.out.println("Xe dung lai!");
	}

	@Override
	public void Break() {
		// TODO Auto-generated method stub
		System.out.println("Xe bat dau phanh!");
	}
}

    

