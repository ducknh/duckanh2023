
public interface IEngine {
	void Start();
	void Stop();
	void Break();
}
