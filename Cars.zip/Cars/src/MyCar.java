
public class MyCar extends Car {
	private String logo;
	
	public MyCar() {
		// TODO Auto-generated constructor stub
	}
	
	public MyCar(String brand, String type, String licensePlate, String chassisNumber, String engineNumber, String logo) {
        super(brand, type, licensePlate, chassisNumber, engineNumber, logo);
        this.logo = logo;
    }
	
	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	public void updateBrandCar(String newbrand) {
		setBrand(newbrand);
	}
	
	public void displayMyCarInfo() {
	    System.out.println("Car Information:");
	    displayInfo();
	    System.out.println("Logo: " + logo);
	}
	
	public static void getOwner() {
		System.out.println("Thong tin loai xe: ");
	}
}
