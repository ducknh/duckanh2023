import java.util.Scanner;

public class Validate {
    public static int nhapSoNguyen() {
    	Scanner s = new Scanner(System.in);
        int so = 0;
        boolean nhapDung = false;

        while (!nhapDung) {
        	String soDongCo = s.nextLine();
            try {
                so = Integer.parseInt(soDongCo);
                return so;
            } catch (NumberFormatException e) {
                System.out.println("Bạn phải nhập số nguyên. Vui lòng thử lại.");
                nhapDung = false;
            }
        }
        return 0;
    }
}

